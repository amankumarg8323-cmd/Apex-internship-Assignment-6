# APEX LARK AI & ML INTERNSHIP - DAY 5
# Data Visualization Using Matplotlib & Seaborn

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 6)

# 1. DATASET COLLECTION
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00352/Online%20Retail.xlsx"
df = pd.read_excel(url)

print("Dataset Shape:", df.shape)
print("\nColumns:", df.columns.tolist())
print("\nData Types:\n", df.dtypes)
print("\nDescriptive Statistics:\n", df.describe(include="all"))

# 2. DATA CLEANING & FEATURE ENGINEERING
df = df.dropna(subset=["CustomerID"])
df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)].copy()
df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
df["TotalSales"] = df["Quantity"] * df["UnitPrice"]
df["Month"] = df["InvoiceDate"].dt.to_period("M").astype(str)
df["Hour"] = df["InvoiceDate"].dt.hour

print("\nCleaned Dataset Shape:", df.shape)

# 3. MATPLOTLIB VISUALIZATIONS
monthly_sales = df.groupby("Month")["TotalSales"].sum()
plt.figure(figsize=(12,6))
plt.plot(monthly_sales.index, monthly_sales.values, marker="o", label="Monthly Sales")
plt.title("Monthly Sales Trend"); plt.xlabel("Month"); plt.ylabel("Total Sales")
plt.xticks(rotation=45); plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()

country_sales = df.groupby("Country")["TotalSales"].sum().sort_values(ascending=False).head(10)
plt.figure(figsize=(12,6))
plt.bar(country_sales.index, country_sales.values, label="Sales")
plt.title("Top 10 Countries by Total Sales"); plt.xlabel("Country"); plt.ylabel("Total Sales")
plt.xticks(rotation=45); plt.grid(axis="y"); plt.legend(); plt.tight_layout(); plt.show()

plt.figure(figsize=(10,6))
plt.hist(df["UnitPrice"], bins=50, edgecolor="black")
plt.title("Distribution of Product Unit Prices"); plt.xlabel("Unit Price"); plt.ylabel("Frequency")
plt.grid(True); plt.tight_layout(); plt.show()

top5 = df.groupby("Country")["TotalSales"].sum().sort_values(ascending=False).head(5)
plt.figure(figsize=(8,8))
plt.pie(top5.values, labels=top5.index, autopct="%1.1f%%", startangle=90)
plt.title("Sales Contribution by Top 5 Countries"); plt.tight_layout(); plt.show()

sample_df = df.sample(min(5000, len(df)), random_state=42)
plt.figure(figsize=(10,6))
plt.scatter(sample_df["Quantity"], sample_df["UnitPrice"], alpha=0.5, label="Products")
plt.title("Quantity vs Unit Price"); plt.xlabel("Quantity"); plt.ylabel("Unit Price")
plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()

# 4. SEABORN VISUALIZATIONS
top_countries = df["Country"].value_counts().head(10).index
plt.figure(figsize=(12,6))
sns.countplot(data=df[df["Country"].isin(top_countries)], x="Country", order=top_countries)
plt.title("Number of Transactions by Country"); plt.xlabel("Country"); plt.ylabel("Transactions")
plt.xticks(rotation=45); plt.tight_layout(); plt.show()

plt.figure(figsize=(10,6))
sns.boxplot(x=df["UnitPrice"])
plt.title("Box Plot of Unit Prices"); plt.xlabel("Unit Price"); plt.tight_layout(); plt.show()

top5_names = df["Country"].value_counts().head(5).index
plt.figure(figsize=(12,6))
sns.violinplot(data=df[df["Country"].isin(top5_names)], x="Country", y="TotalSales")
plt.title("Sales Distribution by Top Countries"); plt.xlabel("Country"); plt.ylabel("Total Sales")
plt.xticks(rotation=45); plt.tight_layout(); plt.show()

pair_data = df[["Quantity", "UnitPrice", "TotalSales"]].sample(min(2000, len(df)), random_state=42)
sns.pairplot(pair_data)
plt.show()

plt.figure(figsize=(10,6))
sns.histplot(df["TotalSales"], bins=50, kde=True)
plt.title("Distribution of Total Sales"); plt.xlabel("Total Sales"); plt.ylabel("Frequency")
plt.tight_layout(); plt.show()

corr = df[["Quantity", "UnitPrice", "TotalSales", "Hour"]].corr()
plt.figure(figsize=(8,6))
sns.heatmap(corr, annot=True, fmt=".2f")
plt.title("Correlation Heatmap"); plt.tight_layout(); plt.show()

# 5. COMPARATIVE ANALYSIS
plt.figure(figsize=(10,6))
sns.scatterplot(data=sample_df, x="Quantity", y="TotalSales", alpha=0.5)
plt.title("Quantity vs Total Sales"); plt.xlabel("Quantity"); plt.ylabel("Total Sales")
plt.grid(True); plt.tight_layout(); plt.show()

plt.figure(figsize=(12,6))
sns.boxplot(data=df[df["Country"].isin(top5_names)], x="Country", y="TotalSales")
plt.title("Comparison of Total Sales Across Countries")
plt.xticks(rotation=45); plt.tight_layout(); plt.show()

print("\nPROJECT COMPLETED SUCCESSFULLY!")
